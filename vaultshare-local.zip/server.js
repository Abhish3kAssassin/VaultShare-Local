const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'storage');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const META_DIR = path.join(DATA_DIR, 'meta');
const LOG_DIR = path.join(DATA_DIR, 'logs');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const FILES_FILE = path.join(DATA_DIR, 'files.json');
const LOGS_FILE = path.join(LOG_DIR, 'activity.log');
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-this-local-secret';
const FILE_ENC_SECRET = process.env.FILE_ENC_SECRET || 'change-this-local-file-secret';
const MAX_FILE_SIZE = 25 * 1024 * 1024;

for (const dir of [DATA_DIR, UPLOAD_DIR, META_DIR, LOG_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

if (!fs.existsSync(USERS_FILE)) {
  fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2));
}
if (!fs.existsSync(FILES_FILE)) {
  fs.writeFileSync(FILES_FILE, JSON.stringify([], null, 2));
}
if (!fs.existsSync(LOGS_FILE)) {
  fs.writeFileSync(LOGS_FILE, '');
}

app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE }
});

function readJson(filePath, fallback = []) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(password, salt, 120000, 32, 'sha256').toString('hex');
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const testHash = crypto.pbkdf2Sync(password, salt, 120000, 32, 'sha256');
  const storedHash = Buffer.from(hash, 'hex');
  return storedHash.length === testHash.length && crypto.timingSafeEqual(storedHash, testHash);
}

function createSessionToken(username) {
  const payload = JSON.stringify({
    username,
    exp: Date.now() + 12 * 60 * 60 * 1000,
    nonce: crypto.randomBytes(8).toString('hex')
  });
  const body = Buffer.from(payload).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function readSession(req) {
  const token = req.cookies.session;
  if (!token) return null;
  const [body, sig] = token.split('.');
  if (!body || !sig) return null;
  const expected = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  if (expected !== sig) return null;
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (Date.now() > data.exp) return null;
    return data;
  } catch {
    return null;
  }
}

function requireAuth(req, res, next) {
  const session = readSession(req);
  if (!session) return res.status(401).json({ error: 'Unauthorized' });
  req.user = session.username;
  next();
}

function deriveFileKey(fileId) {
  return crypto.createHash('sha256').update(`${FILE_ENC_SECRET}:${fileId}`).digest();
}

function encryptBuffer(fileId, buffer) {
  const key = deriveFileKey(fileId);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { encrypted, iv: iv.toString('hex'), tag: tag.toString('hex') };
}

function decryptBuffer(fileId, encryptedBuffer, ivHex, tagHex) {
  const key = deriveFileKey(fileId);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return Buffer.concat([decipher.update(encryptedBuffer), decipher.final()]);
}

function sha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function logEvent(type, actor, details = {}) {
  const line = JSON.stringify({
    time: new Date().toISOString(),
    type,
    actor,
    details
  });
  fs.appendFileSync(LOGS_FILE, line + '\n');
}

function getUsers() {
  return readJson(USERS_FILE, []);
}

function getFiles() {
  return readJson(FILES_FILE, []);
}

function saveFiles(files) {
  writeJson(FILES_FILE, files);
}

function safeFileName(name) {
  return path.basename(name).replace(/[^a-zA-Z0-9._-]/g, '_');
}

function fileView(file, currentUser) {
  const isOwner = file.owner === currentUser;
  const isRecipient = file.allowedUsers.includes(currentUser);
  const expired = Date.now() > file.expiresAt;
  return {
    id: file.id,
    originalName: file.originalName,
    owner: file.owner,
    allowedUsers: file.allowedUsers,
    expiresAt: file.expiresAt,
    createdAt: file.createdAt,
    size: file.size,
    sha256: file.sha256,
    expired,
    canDownload: !expired && (isOwner || isRecipient),
    canManage: isOwner
  };
}

app.post('/api/register', authLimiter, (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password are required' });
  if (!/^[a-zA-Z0-9_-]{3,20}$/.test(username)) return res.status(400).json({ error: 'Use 3-20 letters, numbers, _ or -' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });

  const users = getUsers();
  if (users.some((u) => u.username === username)) {
    return res.status(409).json({ error: 'Username already exists' });
  }

  const { salt, hash } = hashPassword(password);
  users.push({ username, salt, hash, createdAt: Date.now() });
  writeJson(USERS_FILE, users);
  logEvent('register', username, {});
  res.json({ ok: true });
});

app.post('/api/login', authLimiter, (req, res) => {
  const { username, password } = req.body || {};
  const user = getUsers().find((u) => u.username === username);
  if (!user || !verifyPassword(password, user.salt, user.hash)) {
    logEvent('login_failed', username || 'unknown', {});
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = createSessionToken(user.username);
  res.cookie('session', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    maxAge: 12 * 60 * 60 * 1000
  });
  logEvent('login_success', user.username, {});
  res.json({ ok: true, username: user.username });
});

app.post('/api/logout', requireAuth, (req, res) => {
  logEvent('logout', req.user, {});
  res.clearCookie('session');
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  const session = readSession(req);
  res.json({ authenticated: !!session, username: session?.username || null });
});

app.get('/api/users', requireAuth, (req, res) => {
  const users = getUsers().map((u) => u.username).filter((u) => u !== req.user);
  res.json({ users });
});

app.get('/api/files', requireAuth, (req, res) => {
  const files = getFiles()
    .filter((f) => f.owner === req.user || f.allowedUsers.includes(req.user))
    .sort((a, b) => b.createdAt - a.createdAt)
    .map((f) => fileView(f, req.user));
  res.json({ files });
});

app.post('/api/upload', requireAuth, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  let allowedUsers = [];
  try {
    allowedUsers = JSON.parse(req.body.allowedUsers || '[]');
    if (!Array.isArray(allowedUsers)) throw new Error('bad');
  } catch {
    return res.status(400).json({ error: 'allowedUsers must be an array' });
  }

  const allUsers = new Set(getUsers().map((u) => u.username));
  const filteredAllowed = [...new Set(allowedUsers.filter((u) => allUsers.has(u) && u !== req.user))];

  const expiryHours = Math.max(1, Math.min(168, Number(req.body.expiryHours || 24)));
  const fileId = crypto.randomUUID();
  const originalName = safeFileName(req.file.originalname || 'file.bin');
  const { encrypted, iv, tag } = encryptBuffer(fileId, req.file.buffer);
  const storageName = `${fileId}.bin`;
  const storagePath = path.join(UPLOAD_DIR, storageName);
  fs.writeFileSync(storagePath, encrypted);

  const meta = {
    id: fileId,
    storageName,
    originalName,
    owner: req.user,
    allowedUsers: filteredAllowed,
    expiresAt: Date.now() + expiryHours * 60 * 60 * 1000,
    createdAt: Date.now(),
    size: req.file.size,
    sha256: sha256(req.file.buffer),
    iv,
    tag
  };

  const files = getFiles();
  files.push(meta);
  saveFiles(files);
  logEvent('upload', req.user, { fileId, originalName, allowedUsers: filteredAllowed, expiryHours });

  res.json({ ok: true, file: fileView(meta, req.user) });
});

app.get('/api/download/:id', requireAuth, (req, res) => {
  const file = getFiles().find((f) => f.id === req.params.id);
  if (!file) return res.status(404).json({ error: 'File not found' });
  const permitted = file.owner === req.user || file.allowedUsers.includes(req.user);
  if (!permitted) {
    logEvent('download_denied', req.user, { fileId: req.params.id });
    return res.status(403).json({ error: 'Access denied' });
  }
  if (Date.now() > file.expiresAt) {
    logEvent('download_expired', req.user, { fileId: req.params.id });
    return res.status(410).json({ error: 'File link has expired' });
  }

  const encryptedPath = path.join(UPLOAD_DIR, file.storageName);
  if (!fs.existsSync(encryptedPath)) return res.status(404).json({ error: 'Stored file missing' });

  try {
    const encrypted = fs.readFileSync(encryptedPath);
    const decrypted = decryptBuffer(file.id, encrypted, file.iv, file.tag);
    const digest = sha256(decrypted);
    if (digest !== file.sha256) {
      logEvent('integrity_failed', req.user, { fileId: file.id });
      return res.status(500).json({ error: 'Integrity verification failed' });
    }

    logEvent('download_success', req.user, { fileId: file.id, originalName: file.originalName });
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('X-File-SHA256', digest);
    res.setHeader('Content-Disposition', `attachment; filename="${file.originalName}"`);
    res.send(decrypted);
  } catch (error) {
    res.status(500).json({ error: 'Unable to decrypt file' });
  }
});

app.delete('/api/files/:id', requireAuth, (req, res) => {
  const files = getFiles();
  const index = files.findIndex((f) => f.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'File not found' });
  const file = files[index];
  if (file.owner !== req.user) return res.status(403).json({ error: 'Only owner can delete file' });

  const encryptedPath = path.join(UPLOAD_DIR, file.storageName);
  if (fs.existsSync(encryptedPath)) fs.unlinkSync(encryptedPath);
  files.splice(index, 1);
  saveFiles(files);
  logEvent('delete_file', req.user, { fileId: file.id, originalName: file.originalName });
  res.json({ ok: true });
});

app.get('/api/logs', requireAuth, (req, res) => {
  const raw = fs.readFileSync(LOGS_FILE, 'utf8').trim();
  const entries = raw
    ? raw.split('\n').map((line) => JSON.parse(line)).filter((entry) => entry.actor === req.user || entry.details?.allowedUsers?.includes?.(req.user))
    : [];
  res.json({ logs: entries.slice(-100).reverse() });
});

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large. Limit is 25 MB.' });
  }
  res.status(500).json({ error: 'Unexpected server error' });
});

app.listen(PORT, () => {
  console.log(`VaultShare Local running on http://localhost:${PORT}`);
});
