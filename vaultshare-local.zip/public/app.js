const authSection = document.getElementById('authSection');
const appSection = document.getElementById('appSection');
const userBadge = document.getElementById('userBadge');
const logoutBtn = document.getElementById('logoutBtn');
const registerForm = document.getElementById('registerForm');
const loginForm = document.getElementById('loginForm');
const uploadForm = document.getElementById('uploadForm');
const allowedUsersSelect = document.getElementById('allowedUsers');
const filesGrid = document.getElementById('filesGrid');
const logsList = document.getElementById('logsList');
const refreshFilesBtn = document.getElementById('refreshFilesBtn');
const refreshLogsBtn = document.getElementById('refreshLogsBtn');
const toast = document.getElementById('toast');

let currentUser = null;

function showToast(message, kind = 'success') {
  toast.textContent = message;
  toast.className = `toast ${kind}`;
  toast.classList.remove('hidden');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => toast.classList.add('hidden'), 3200);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'same-origin',
    ...options
  });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) {
    throw new Error(data.error || data || 'Request failed');
  }
  return data;
}

function bytesToHuman(size) {
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let value = size;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i += 1;
  }
  return `${value.toFixed(value < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function formatDate(ts) {
  return new Date(ts).toLocaleString();
}

function timeLeft(expiresAt) {
  const diff = expiresAt - Date.now();
  if (diff <= 0) return 'Expired';
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  if (hours >= 24) return `${Math.floor(hours / 24)}d ${hours % 24}h left`;
  if (hours > 0) return `${hours}h ${minutes}m left`;
  return `${minutes}m left`;
}

async function hydrateUsers() {
  const { users } = await api('/api/users');
  allowedUsersSelect.innerHTML = users.map((user) => `<option value="${user}">${user}</option>`).join('');
}

function fileCard(file) {
  const badgeClass = file.expired ? 'danger' : file.canDownload ? 'ok' : 'warn';
  const badgeText = file.expired ? 'Expired' : file.canDownload ? 'Ready' : 'Restricted';
  return `
    <article class="file-card">
      <div class="badge ${badgeClass}">${badgeText}</div>
      <div class="file-title">${file.originalName}</div>
      <div class="meta-row">
        <span><strong>Owner:</strong> ${file.owner}</span>
        <span><strong>Size:</strong> ${bytesToHuman(file.size)}</span>
        <span><strong>Uploaded:</strong> ${formatDate(file.createdAt)}</span>
        <span><strong>Expires:</strong> ${formatDate(file.expiresAt)} (${timeLeft(file.expiresAt)})</span>
        <span><strong>SHA-256:</strong> ${file.sha256.slice(0, 18)}...</span>
        <span><strong>Shared with:</strong> ${file.allowedUsers.length ? file.allowedUsers.join(', ') : 'Only owner'}</span>
      </div>
      <div class="card-actions">
        ${file.canDownload ? `<button class="primary-btn" onclick="downloadFile('${file.id}', '${file.originalName}')">Download</button>` : ''}
        ${file.canManage ? `<button class="ghost-btn" onclick="deleteFile('${file.id}')">Delete</button>` : ''}
      </div>
    </article>
  `;
}

async function hydrateFiles() {
  const { files } = await api('/api/files');
  filesGrid.innerHTML = files.length
    ? files.map(fileCard).join('')
    : '<div class="file-card"><div class="file-title">No files yet</div><div class="meta-row"><span>Upload one to start secure sharing.</span></div></div>';
}

function logLabel(type) {
  return type.replaceAll('_', ' ');
}

async function hydrateLogs() {
  const { logs } = await api('/api/logs');
  logsList.innerHTML = logs.length
    ? logs.map((log) => `
        <div class="log-item">
          <strong>${logLabel(log.type)}</strong>
          <span>${formatDate(log.time)}</span>
          <span>${JSON.stringify(log.details)}</span>
        </div>
      `).join('')
    : '<div class="log-item"><strong>No activity yet</strong><span>Your upload, download, and auth events will appear here.</span></div>';
}

async function refreshAuthenticatedUI() {
  await Promise.all([hydrateUsers(), hydrateFiles(), hydrateLogs()]);
}

function setAuthenticated(username) {
  currentUser = username;
  authSection.classList.add('hidden');
  appSection.classList.remove('hidden');
  userBadge.textContent = `Signed in as ${username}`;
  userBadge.classList.remove('hidden');
  logoutBtn.classList.remove('hidden');
}

function setLoggedOut() {
  currentUser = null;
  appSection.classList.add('hidden');
  authSection.classList.remove('hidden');
  userBadge.classList.add('hidden');
  logoutBtn.classList.add('hidden');
}

registerForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(registerForm);
  try {
    await api('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.fromEntries(formData.entries()))
    });
    registerForm.reset();
    showToast('Account created. You can log in now.');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(loginForm);
  try {
    const result = await api('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.fromEntries(formData.entries()))
    });
    setAuthenticated(result.username);
    await refreshAuthenticatedUI();
    loginForm.reset();
    showToast('Logged in successfully.');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

logoutBtn.addEventListener('click', async () => {
  try {
    await api('/api/logout', { method: 'POST' });
    setLoggedOut();
    showToast('Logged out.');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

uploadForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(uploadForm);
  const selectedUsers = [...allowedUsersSelect.selectedOptions].map((opt) => opt.value);
  formData.set('allowedUsers', JSON.stringify(selectedUsers));

  try {
    await api('/api/upload', {
      method: 'POST',
      body: formData
    });
    uploadForm.reset();
    [...allowedUsersSelect.options].forEach((opt) => { opt.selected = false; });
    await Promise.all([hydrateFiles(), hydrateLogs()]);
    showToast('File encrypted and uploaded.');
  } catch (error) {
    showToast(error.message, 'error');
  }
});

refreshFilesBtn.addEventListener('click', () => hydrateFiles().catch((error) => showToast(error.message, 'error')));
refreshLogsBtn.addEventListener('click', () => hydrateLogs().catch((error) => showToast(error.message, 'error')));

window.downloadFile = async function downloadFile(id, originalName) {
  try {
    const response = await fetch(`/api/download/${id}`, { credentials: 'same-origin' });
    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Download failed');
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = originalName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    await hydrateLogs();
    showToast(`Downloaded ${originalName}`);
  } catch (error) {
    showToast(error.message, 'error');
  }
};

window.deleteFile = async function deleteFile(id) {
  try {
    await api(`/api/files/${id}`, { method: 'DELETE' });
    await Promise.all([hydrateFiles(), hydrateLogs()]);
    showToast('File deleted.');
  } catch (error) {
    showToast(error.message, 'error');
  }
};

async function bootstrap() {
  try {
    const me = await api('/api/me');
    if (me.authenticated) {
      setAuthenticated(me.username);
      await refreshAuthenticatedUI();
    } else {
      setLoggedOut();
    }
  } catch {
    setLoggedOut();
  }
}

bootstrap();
