# VaultShare Local

A local-first secure file transfer web app with:
- user registration and login
- encrypted file storage (AES-256-GCM)
- integrity verification (SHA-256)
- access control per file
- expiry windows
- transfer logs
- no database (filesystem + JSON metadata only)

## Tech
- Node.js + Express
- HTML, CSS, JavaScript frontend
- Multer for uploads
- Node crypto for encryption and hashing

## Run locally

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000
```

## Notes
- Files are encrypted before being written to disk.
- The server decrypts files only during authorized downloads.
- Metadata is stored in `storage/files.json`.
- User records are stored in `storage/users.json`.
- Logs are stored in `storage/logs/activity.log`.
- This app is intended for local demos, resume projects, and learning.

## Optional environment variables

```bash
SESSION_SECRET=replace-me
FILE_ENC_SECRET=replace-me
PORT=3000
```

## Suggested demo flow
1. Register two users.
2. Login as user A.
3. Upload a file and share it with user B.
4. Login as user B and download it.
5. Try waiting past expiry or download as an unauthorized user.
6. Review the logs.
